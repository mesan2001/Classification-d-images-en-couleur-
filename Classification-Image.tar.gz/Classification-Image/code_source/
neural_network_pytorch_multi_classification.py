import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from sklearn import datasets
import torch as th
import torch
from tqdm import tqdm
import torch.optim as optim
import pickle
from torch.nn import functional as F

#0) Choix d'une graine aléatoire
np.random.seed(0)
th.manual_seed(0)
th.cuda.manual_seed(0)


with open("dataset_images_train",'rb') as fo:
    TRAIN = pickle.load(fo,encoding='bytes')

X = TRAIN["data"]
Y = TRAIN["target"]
# Normalisation des données (Moyenne et Écart-Type)
X_mean = X.mean()
X_std = X.std()
X = (X - X_mean) / X_std

d = X.shape[1]
k = 10

#2) fonction qui calcule les prédictions (0 ou 1) à partir des sorties du modèle
def prediction(f):
    return torch.argmax(f, dim=1)

#3) Fonction qui calcule le taux d'erreur en comparant les y prédits avec les y réels
def error_rate(y_pred,y):
    return ((y_pred != y).sum().float())/y_pred.size()[0]




#5) Séparation aléatoire du dataset en ensemble d'apprentissage (70%) et de test (30%)
indices = np.random.permutation(X.shape[0])
training_idx, test_idx = indices[:int(X.shape[0]*0.7)], indices[int(X.shape[0]*0.7):]
X_train = X[training_idx,:]
y_train = Y[training_idx]

X_test = X[test_idx,:]
y_test = Y[test_idx]



    #6) Création du modèle de régression logistique multivarié. Il étend la classe th.nn.Module de la librairie Pytorch
"""
    class Neural_network_binary_classif(th.nn.Module):

        # Constructeur qui initialise le modèle
        def __init__(self,d,h1,h2):
            super(Neural_network_binary_classif, self).__init__()

            self.layer1 = th.nn.Linear(d, h1)
            self.layer2 = th.nn.Linear(h1, h2)
            self.layer3 = th.nn.Linear(h2, 1)

            self.layer1.reset_parameters()
            self.layer2.reset_parameters()
            self.layer3.reset_parameters()

        # Implémentation de la passe forward du modèle
        def forward(self, x):
            phi1 = torch.sigmoid(self.layer1(x))
            phi2 = torch.sigmoid(self.layer2(phi1))

            return torch.sigmoid(self.layer3(phi2)).view(-1)

"""

#Une seconde version encore plus flexible
class NeuralNetwork(th.nn.Module):
    def __init__(self, d, h, k, n_layers=3): # le nombre de couche qui peut etre changé
        super(NeuralNetwork, self).__init__()
        
        # Liste des couches cachées
        layers = []
        input_size = d
        
        # Ajouter les couches cachées
        for _ in range(n_layers):
            layers.append(th.nn.Linear(input_size, h))
            input_size = h  # La sortie de la couche précédente devient l'entrée de la suivante
        
        # la couche de sortie (10 neurones pour 10 classes)
        layers.append(th.nn.Linear(h, 10))  # 10 neurones pour les 10 classes
        
        self.network = th.nn.Sequential(*layers)

    def forward(self, x):
        # Appliquer sigmoid ou une autre activation aux couches cachées
        for layer in self.network[:-1]:  
            x = th.sigmoid(layer(x))  
        x = self.network[-1](x)
        return F.softmax(x, dim=1)

nnet = NeuralNetwork(d, h=50, k=10, n_layers=3)



device = "cpu"

nnet = nnet.to(device)


# Conversion des données en tenseurs Pytorch et envoi sur le device

X_train = th.from_numpy(X_train).float().to(device)
y_train = th.from_numpy(y_train).float().to(device)

X_test = th.from_numpy(X_test).float().to(device)
y_test = th.from_numpy(y_test).float().to(device)


eta = 0.01

y_train = y_train.long()
criterion = th.nn.CrossEntropyLoss()
#loss = criterion(f_train, y_train)

# J'ai fait le choix d'utilisé ici optim.Adam
optimizer = optim.Adam(nnet.parameters(), lr=eta)

# tqdm permet d'avoir une barre de progression
nb_epochs = 10000 
pbar = tqdm(range(nb_epochs))

for i in pbar:
    # Remise à zéro des gradients
    optimizer.zero_grad()

    f_train = nnet(X_train)
    loss = criterion(f_train,y_train)
    
    # Calculs des gradients
    loss.backward()

    # Mise à jour des poids du modèle avec l'optimiseur choisi et en fonction des gradients calculés
    optimizer.step()

    if (i % 1000 == 0):

        y_pred_train = prediction(f_train)

        error_train = error_rate(y_pred_train,y_train)
        loss = criterion(f_train,y_train)

        f_test = nnet(X_test)
        y_pred_test = prediction(f_test)

        error_test = error_rate(y_pred_test, y_test)

        pbar.set_postfix(iter=i, loss = loss.item(), error_train=error_train.item(), error_test=error_test.item())



#prediction sur les vrais données  :
with open("data_images_test",'rb') as fo:
    TEST = pickle.load(fo,encoding='bytes')
#X_train = th.from_numpy(X_train).float().to(device)
X_test_final = TEST["data"]
X_test_final = (X_test_final - X_mean) / X_std # normalisation
X_test_final = th.from_numpy(X_test_final).float().to(device)
# avec une couche
f_test = nnet(X_test_final)
y_pred_test = prediction(f_test)
y_pred_test = y_pred_test.detach().cpu().numpy()

np.savetxt("images_test_predictions.csv" , y_pred_test)