import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import ListedColormap
from tqdm import tqdm  # Veille à ce que cette ligne soit présente dans ton script
import pickle
from sklearn.manifold import TSNE
from sklearn.neighbors import KNeighborsClassifier
                                                # PREPARATION DES DONNÉES

#Tenseur de taille(3,32,32) -> 3 matrices de taille 32X32
#20000 lignes 

#3 PHASE D'ENTRAINEMENT ET DE VISUALISATION 

with open("dataset_images_train",'rb') as fo:
    TRAIN = pickle.load(fo,encoding='bytes')


X = TRAIN["data"]
Y = TRAIN["target"]
#print( "nombre de classe à prédire : " ,  len(np.unique(Y)))

np.random.seed(42)  
indices = np.random.permutation(X.shape[0])  

training_idx = indices[:int(X.shape[0]*0.6)] # prendre 60% pour le test (apres j'ai repris 80/20)
valid_idx = indices[int(X.shape[0]*0.6):]  # # prendre 40% pour la validation 



X_train =  X[training_idx] #data  test
Y_train = Y[training_idx] #label test

X_valid =  X[valid_idx] # data validation 
Y_valid = Y[valid_idx] # label validation 



# 3.1 VISUALISATION DES DONNÉes
        # 1-> affichage de la premiere image 


plt.imshow(X_train[0].reshape(3,32,32).transpose((1,2,0)))
plt.show()

        # 2-> Fonction prenant le numéro d'une classe et qui affiche 10 image de cette classe

def afficher_images_classe(class_num, X_data, Y_data): # class_num =  le numéro de la classe

    indices = np.where(Y_data == class_num)[0]  # Trouver les indices des images de la classe donnée
    if len(indices) == 0:
        print(f"Aucune image trouvée pour la classe {class_num}")
        return
    
    indices = indices[:10]  # Sélectionner les 10 premières images
    fig, axes = plt.subplots(2, 5, figsize=(10, 5))  # Création d'un affichage en 2 lignes et 5 colonnes
    
    for i, ax in enumerate(axes.flat):
        if i < len(indices):
            img = X_data[indices[i]].reshape(3, 32, 32).transpose((1, 2, 0))  # Reformater l'image
            ax.imshow(img)
            ax.axis("off")  # Supprimer les axes
    
    plt.show()

# Exemple d'utilisation :
for i in range(10):
    afficher_images_classe(i, X_train, Y_train)


         #3 -> Projection 2D de 3000 images avec t-SNE

nb_images_plot = 3000
X_sample = X[:nb_images_plot]
Y_sample = Y[:nb_images_plot]

# Réduction de dimension avec t-SNE
X_tsne = TSNE(n_components=2, random_state=42).fit_transform(X_sample)

# Création du scatter plot avec une légende
plt.figure(figsize=(8, 6))
scatter = plt.scatter(X_tsne[:, 0], X_tsne[:, 1], c=Y_sample, cmap='tab10', alpha=0.7)

# Ajouter une légende avec les labels des classes
classes = np.unique(Y_sample)
legend_labels = [f"Classe {c}" for c in classes]
legend = plt.legend(handles=scatter.legend_elements()[0], labels=legend_labels, title="Classes")
plt.gca().add_artist(legend)

# Ajout du titre et affichage
plt.title("Projection 2D de 3000 images avec t-SNE")
plt.xlabel("t-SNE Dim 1")
plt.ylabel("t-SNE Dim 2")
plt.show()



# 3.2 PREMIERE MODELISATION
        #1-> Algo des k plus proches voisins

def evaluation(Y_true, Y_pred, verbose=True):

    # Initialiser les compteurs
    TP = np.zeros(10)  # Vrais positifs
    FP = np.zeros(10)  # Faux positifs
    TN = np.zeros(10)  # Vrais négatifs
    FN = np.zeros(10)  # Faux négatifs
    
    total = len(Y_true)

    for i in range(total):
        predicted_class = Y_pred[i]
        true_class = Y_true[i]

        for class_idx in range(10):
            if predicted_class == class_idx and true_class == class_idx:
                TP[class_idx] += 1
            elif predicted_class == class_idx and true_class != class_idx:
                FP[class_idx] += 1
            elif predicted_class != class_idx and true_class == class_idx:
                FN[class_idx] += 1
            else:
                TN[class_idx] += 1

    # Calcul de l'accuracy globale
    accuracy = np.sum(TP + TN) / total # la précision à recalculer 
   
    if verbose:
        for class_idx in range(10):
            precision = TP[class_idx] / (TP[class_idx] + FP[class_idx]) if (TP[class_idx] + FP[class_idx]) != 0 else 0
            recall = TP[class_idx] / (TP[class_idx] + FN[class_idx]) if (TP[class_idx] + FN[class_idx]) != 0 else 0
            f1_score = 2 * (precision * recall) / (precision + recall) if (precision + recall) != 0 else 0
            
            print(f"Classe {class_idx}:")
            print(f"  Précision : {precision:.4f}")
            print(f"  Rappel : {recall:.4f}")
            print(f"  F-mesure : {f1_score:.4f}")

        print(f"\nPrécision globale : {accuracy:.4f}")

    return accuracy

# Entraînement du modèle KNN avec sklearn
        # Évaluation des performances
        #2 ->. Testez votre algorithme sur le jeu d’entraînement afin de trouver le meilleur nombre de voisins à prendre en compte.

list_accuracy = []

for k in tqdm(range(1, 50, 2)):  # Test de  k entre 1 et 50
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train, Y_train)
    
    Y_pred = knn.predict(X_valid)
    
    # Évaluer l'accuracy et stocker le résultat
    acc = evaluation(Y_valid, Y_pred, verbose=False)
    list_accuracy.append(acc/10)
    
print(list_accuracy)

        # 3-> Traçage de la courbe qui montre l'évolution de l'accuracy en fonction de k

x=range(1,50,2)
y=list_accuracy

plt.plot(x,y)
plt.xlabel("k")
plt.ylabel("accuracy")

plt.show()

            #  La valeur de k qui me  semble la plus pertinente 
k_best = 9  
            # 4 ->Application de l'algorithme des k plus proches voisins sur les données de test (fichier data_images_test)

with open("data_images_test",'rb') as fo:
    TEST = pickle.load(fo,encoding='bytes')

X_test = TEST["data"]
knn = KNeighborsClassifier(n_neighbors=k_best)
knn.fit(X_train, Y_train)

# Prédiction sur l'ensemble de validation
Y_pred = knn.predict(X_test)


np.savetxt("images_test_predictions.csv" , Y_pred)


# Les autres modélisations plus avancées sont dans les fichier cnn.py , regression_pytorch.py et neural_network_pytorch_multi_classification.py

#Cordialement,
#Messan Joseph ANANI
