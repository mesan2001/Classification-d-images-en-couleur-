import numpy as np
import torch
import matplotlib.pyplot as plt
import torch.optim as optim
import torch.nn.functional as F
import torch.nn as nn
import torch as th
from tqdm import tqdm
import pickle
from torch.utils.data import DataLoader, TensorDataset
from torchvision import transforms


transforms = transforms.Compose([
    transforms.Resize((32, 32)),  # Assurez-vous que la taille correspond
    transforms.ToTensor()  # Ne pas utiliser .view() dans la transformation
])


# Initialisation des graines pour la reproductibilité
np.random.seed(0)
torch.manual_seed(0)
torch.cuda.manual_seed(0)

# Chargement des données d'entraînement
with open("dataset_images_train", 'rb') as fo:
    TRAIN = pickle.load(fo, encoding='bytes')

X = TRAIN["data"]
Y = TRAIN["target"]

X = X.reshape(-1, 3, 32, 32)  

# Normalisation des données
X_mean = X.mean()
X_std = X.std()
X = (X - X_mean) / X_std


d = X.shape[1]
k = 10  # Nombre de classes



# Fonction pour calculer les prédictions
def prediction(f):
    return torch.argmax(f, 1)

# Fonction pour calculer le taux d'erreur
def error_rate(y_pred, y):
    return ((y_pred != y).sum().float()) / y_pred.size(0)

class Neural_network_multiclass(th.nn.Module):
    def __init__(self, d, k, h1, h2, dropout):
        super(Neural_network_multiclass, self).__init__()

        self.dropout = dropout

        # Modifier la première couche pour accepter 3 canaux (RGB)
        self.conv1 = nn.Conv2d(3, 32, 5)  # 3 canaux pour RGB
        self.conv2 = nn.Conv2d(32, 32, 5)
        self.conv3 = nn.Conv2d(32, 32, 5)

        self.layer1 = th.nn.Linear(32*20*20, h1)
        self.layer2 = th.nn.Linear(h1, h2)
        self.layer3 = th.nn.Linear(h2, k)

        self.layer1.reset_parameters()
        self.layer2.reset_parameters()
        self.layer3.reset_parameters()

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.relu(self.conv2(x))
        x = F.relu(self.conv3(x))

        x = x.view(-1, 32*20*20)

        x = F.relu(self.layer1(x))
        x = F.dropout(x, p=self.dropout, training=self.training)

        x = F.relu(self.layer2(x))
        x = F.dropout(x, p=self.dropout, training=self.training)

        return self.layer3(x)  # Ne pas appliquer softmax ici

# Initialisation du modèle
nnet = Neural_network_multiclass(d, k, 200, 100, 0.2)

# Spécification du matériel utilisé (CPU ou GPU)
device = "cpu"  # Changez à "cuda" si vous avez un GPU
nnet = nnet.to(device)

# Préparer les données avec DataLoader
X_tensor = torch.tensor(X, dtype=torch.float32)
Y_tensor = torch.tensor(Y, dtype=torch.long)




# Créer un dataset et des DataLoaders. J'ai testé également avec la version du prof avec la classe suivante et j'ai obtenu le meme resultat:
"""
class myDataset(torch.utils.data.Dataset):

    def __init__(self, data, label):
        # Initialise dataset from source dataset
        self.data = data
        self.label  = label

    def __len__(self):
        # Return length of the dataset
        return len(self.data)

    def __getitem__(self, idx):
        # Return one element of the dataset according to its index
        return self.data[idx], self.label[idx]
"""
dataset = TensorDataset(X_tensor, Y_tensor)

# Diviser en ensemble d'entraînement et de validation (80% / 20%)

train_size = int(0.8 * len(dataset))
val_size = len(dataset) - train_size
train_dataset, val_dataset = torch.utils.data.random_split(dataset, [train_size, val_size])


# DataLoader
trainloader = DataLoader(train_dataset, batch_size=50, shuffle=True)
valloader = DataLoader(val_dataset, batch_size=50, shuffle=False)

# Fonction de perte et optimiseur
criterion = torch.nn.CrossEntropyLoss()  # Pour la classification multiclasse
optimizer = optim.Adam(nnet.parameters())


# Nombre d'époques
nb_epochs = 1000 #100000
pbar = tqdm(range(nb_epochs))

# Initialisation de l'erreur de test
error_test = np.nan

# Entraînement du modèle
for epoch in pbar:
    cpt_batch = 0
    for images, labels in trainloader:
        images, labels = images.to(device), labels.to(device)
        
        # Remise à zéro des gradients
        optimizer.zero_grad()
        
        f_train = nnet(images)
        # Calcul de la perte
        
        loss = criterion(f_train, labels)
        
        # Régularisation L2
        l2_lambda = 0.001
        l2_reg = torch.tensor(0.)
        for param in nnet.parameters():
            l2_reg += torch.norm(param).pow(2)
        loss += l2_lambda * l2_reg

        # Calcul des gradients
        loss.backward()

        # Mise à jour des poids
        optimizer.step()

        cpt_batch += 1
        y_pred_train = prediction(f_train)
        error_train = error_rate(y_pred_train, labels)

        pbar.set_postfix(iter=epoch, idx_batch=cpt_batch, loss=loss.item(), error_train=error_train.item(), error_test=error_test, l2_reg=l2_reg)


    # Évaluation sur l'ensemble de validation
    error_avg = 0
    all_count = 0
    for images, labels in valloader:
        images, labels = images.to(device), labels.to(device)
        f_test = nnet(images)
        y_pred_test = prediction(f_test)
        error_avg += error_rate(y_pred_test, labels)
        all_count += 1

    error_test = (error_avg / all_count).item()

    pbar.set_postfix(iter=epoch, idx_batch=cpt_batch, loss=loss.item(), error_train=error_train, error_test=error_test)

# Chargement des données de test
with open("data_images_test", 'rb') as fo:
    TEST = pickle.load(fo, encoding='bytes')

# Normalisation des données de test
X_test_final = TEST["data"]
X_mean = np.mean(X_test_final, axis=0)
X_std = np.std(X_test_final, axis=0)
X_test_final = (X_test_final - X_mean) / X_std  # normalisation

X_test_final = X_test_final.reshape(-1, 3, 32, 32)  # Assurer la forme correcte (batch_size, 3, 32, 32)


# Conversion en tensor
X_test_final = th.from_numpy(X_test_final).float().to(device)

# Prédiction avec le modèle entraîné
f_test = nnet(X_test_final)  # Passer les données de test dans le réseau
y_pred_test = prediction(f_test)  # Obtenir les prédictions

# Convertir les prédictions en numpy array
y_pred_test = y_pred_test.detach().cpu().numpy()

# Sauvegarder les prédictions dans un fichier CSV
np.savetxt("images_test_predictions.csv", y_pred_test, delimiter=",")
